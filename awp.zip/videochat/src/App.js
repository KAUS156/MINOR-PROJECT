import React from 'react';

import Video from './components/Video';
function App() {
  return (
    <div>
    <Video></Video>
    </div>
  );
}

export default App;
