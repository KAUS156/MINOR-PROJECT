// import React from 'react';

// const Join = () => {
//     const roomURL = "http://localhost:3000/room/sdfg";

//     return (
//         <div>
//             <p>Share this link with others to join the room:</p>
//             <a href={roomURL}>{roomURL}</a>
//         </div>
//     );
// };

// export default Join;
